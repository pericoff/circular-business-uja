# Circular Business Challenge UJA
## Guiones de introducción para vídeo — 4 rondas

Textos originales preparados para locución y vídeo docente. Duración aproximada: 60–75 segundos por vídeo según velocidad. Los escenarios y cifras corresponden a una simulación ficticia.


---

### RONDA 1 · LA IDEA SE CONVIERTE EN EMPRESA

**Locución**

Imagina que acabas de fundar una empresa en el sector de materiales de construcción sostenible. Tienes una oportunidad: transformar una nueva solución constructiva en un negocio real. Pero no estás solo. Otras tres empresas competirán por los mismos clientes, con recursos iniciales idénticos. Dispones de doscientos cincuenta mil euros y debes decidir qué vas a priorizar: capacidad de producción, investigación, sostenibilidad o comercialización. También fijarás tu primer precio de venta. Recuerda que no se trata únicamente de fabricar un material más ecológico. Tienes que demostrar que satisface una necesidad, que puede venderse y que tu empresa puede sostenerse económicamente. Tus decisiones de hoy serán el punto de partida de toda la competición. ¿Qué modelo de negocio vas a construir?

**Propuesta visual**

- Mapa de Jaén, materiales sostenibles, equipos reunidos
- Imágenes de plantas productivas, gráficos de inversión, elección de prioridades
- Pantalla del simulador con el envío de decisiones


**Pantalla final:** «¿Qué modelo de negocio construirás?»


---

### RONDA 2 · EL MERCADO DICTA SENTENCIA

**Locución**

Tu empresa ha iniciado su actividad y ahora llega la prueba decisiva: el mercado. Los clientes no compran una idea, compran una solución que les aporte valor. Compararán el precio, la calidad, la sostenibilidad y la capacidad de respuesta de las cuatro empresas. La demanda total es limitada, de modo que vuestras decisiones están conectadas: si una empresa gana cuota, otra puede perderla. Antes de decidir, estudia los resultados del ejercicio anterior. ¿Has vendido lo previsto? ¿Has conseguido un margen suficiente? ¿Te sobra capacidad productiva? En esta ronda tendrás que equilibrar ambición y prudencia. Bajar el precio puede atraer compradores, pero también reducir tus beneficios. Invertir en innovación puede reforzar tu posición, aunque consume tesorería. ¿Qué cambiarás para mejorar tu competitividad?

**Propuesta visual**

- Obras y clientes analizando productos
- Gráfico de cuotas de mercado y comparación de precios
- Resultados de las cuatro empresas y pregunta final


**Pantalla final:** «¿Cómo ganarás cuota de mercado?»


---

### RONDA 3 · LA CRISIS PONE A PRUEBA LA ESTRATEGIA

**Locución**

Las empresas no compiten en un entorno estable. Los precios de las materias primas cambian, los clientes modifican sus preferencias y pueden aparecer nuevas exigencias ambientales o técnicas. En esta tercera ronda, tu empresa afrontará una situación inesperada. El profesor anunciará un evento de mercado que alterará las condiciones de juego. Tendrás que reaccionar con la información disponible y con los recursos que hayas conservado. Una empresa muy rentable puede descubrir que depende demasiado de un insumo. Otra que invirtió en circularidad puede encontrar una ventaja frente a la crisis. Analiza el riesgo, revisa tus costes, protege tu liquidez y explica por qué tu nueva estrategia es la más adecuada. No siempre gana quien más crece: a veces gana quien mejor se adapta.

**Propuesta visual**

- Noticia de subida de materias primas, indicadores de mercado
- Equipo debatiendo y revisando recursos
- Panel de decisiones y símbolo de incertidumbre


**Pantalla final:** «¿Cómo responderás a la crisis?»


---

### RONDA 4 · EL MOMENTO DE DEMOSTRAR EL VALOR

**Locución**

Has llegado a la ronda final del Circular Business Challenge. Tu empresa ya ha competido, ha tomado decisiones de inversión y se ha enfrentado a la incertidumbre. Ahora debes demostrar que tu modelo de negocio merece continuar. Analiza tus resultados acumulados: ventas, cuota de mercado, tesorería, calidad y circularidad. Decide si es el momento de consolidar, invertir o proteger los recursos disponibles. Recuerda que el mejor negocio no es necesariamente el que más factura, sino el que combina viabilidad económica, desempeño técnico y sostenibilidad. Tras esta última ronda tendrás que defender tu estrategia ante el profesor, que actuará como inversor. ¿Qué has aprendido de tus decisiones? ¿Qué harías de otra forma? Y, sobre todo, ¿por qué merece la pena apostar por tu empresa?

**Propuesta visual**

- Evolución de resultados de las rondas
- Equipo preparando presentación para inversores
- Clasificación final y defensa del proyecto


**Pantalla final:** «¿Por qué invertir en tu empresa?»
